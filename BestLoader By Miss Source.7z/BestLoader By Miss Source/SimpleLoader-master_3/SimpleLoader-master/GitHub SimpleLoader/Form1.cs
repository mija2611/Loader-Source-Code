﻿//SimpleLoader by Wilson, https://github.com/WilsonPublic/SimpleLoader [Open Source Cheat Loader]
//This is very noob friendly and can easily be adapted, this has no form of protection against cracking so please come up with your own ideas on how to prevent cracking
//I recommend using Dot Net Reactor to protect your programs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ManualMapInjection.Injection;
using System.Net;
using System.IO;
using System.Diagnostics;

//    ___        __  __ _       
//   | _ )_  _  |  \/  (_)______
//   | _ | || | | |\/| | (_-(_-<
//   |___/\_, | |_|  |_|_/__/__/
//        |__/ 
// https://www.youtube.com/channel/UCOKeny3Q-RLaHT2PmFEpNTQ



namespace WindowsFormsApp2
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        string HWID;

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            metroCheckBox1.Checked = false;

            DirectoryInfo checkcheat = new DirectoryInfo(@"C:\Loader");
            WebClient wb = new WebClient();
            string cheatatt = wb.DownloadString("https://raw.githubusercontent.com/mija2611/Loader-Source-Code/main/cheatatt.txt?token=ARMRAPWLMNKMTVD6B3UQEU27RCZRA"); // Coloque o link RAW do seu .txt que representa o download direto do seu cheat
            metroTextBox2.Text = cheatatt;


            if (checkcheat.Exists == false)
            {
                MessageBox.Show("Erro ao carregar arquivos");
                Application.Exit();
            }
            HWID = System.Security.Principal.WindowsIdentity.GetCurrent().User.Value;
            metroTextBox1.Text = HWID;
            Clipboard.SetText(HWID);
            StreamReader x;
            string Caminho = (@"C:\Loader\cheatupdate.txt");
            x = File.OpenText(Caminho);
            string linha = x.ReadLine();
            metroTile1.Text = (linha);
            if (metroTile1.Text == "Detectável")
            {
                MessageBox.Show("Cheat detectável", "Cheat em manutenção");

                metroButton1.Enabled = false;
                timer1.Stop();
            }






        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
          
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            WebClient wb = new WebClient();
            string HWIDLIST = wb.DownloadString("https://raw.githubusercontent.com/mija2611/Loader-Source-Code/main/hwid.txt?token=ARMRAPQIF45OC3V44SLS3O27RCZYY"); // Coloque o link RAW do seu .txt que representa o seu Banco de Dados
           
            if (HWIDLIST.Contains(metroTextBox1.Text))
            {
                string mainpath = @"C:\Windows\random.dll"; //Local onde será realizado o download da sua DLL, altere caso dê erro
                wb.DownloadFile(metroTextBox2.Text, mainpath); // Download da sua DLL
                var name = "csgo";
                var target = Process.GetProcessesByName(name).FirstOrDefault();
                var path = mainpath;
                var file = File.ReadAllBytes(path);

                //Checking if the DLL isn't found
                if (!File.Exists(path))
                {
                    MessageBox.Show("Error: DLL not found");
                    return;
                }

                //Injection, just leave this alone if you are a beginner
                var injector = new ManualMapInjector(target) { AsyncInjection = true };
                label2.Text = $"hmodule = 0x{injector.Inject(file).ToInt64():x8}";
                MessageBox.Show("Injetado com Sucesso");
                timer1.Stop();
                metroButton1.Enabled = false;

                if(metroCheckBox1.Checked == true)
                {
                    Application.Exit();
                }

                if (System.IO.File.Exists(mainpath)) //Checking if the DLL exists
                {
                    System.IO.File.Delete(mainpath); //Deleting the DLL
                }
            }
            else
            {
                MessageBox.Show("Acesso não autorizado");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Process[] TargetProcess1 = Process.GetProcessesByName("csgo"); //

            {

                if (TargetProcess1.Length == 0)

                {
                    metroButton1.Enabled = false;
                    metroTextBox3.Text = ("Waiting for csgo.exe");
                    metroTextBox3.Style = MetroFramework.MetroColorStyle.Red;





                }
                else
                {
                    metroButton1.Enabled = true;

                    metroTextBox3.Text = ("Ready to Inject");

                    metroTextBox3.Style = MetroFramework.MetroColorStyle.Green;


                }

            }
        }

        private void metroTile1_Click(object sender, EventArgs e)
        {

        }
    }

}