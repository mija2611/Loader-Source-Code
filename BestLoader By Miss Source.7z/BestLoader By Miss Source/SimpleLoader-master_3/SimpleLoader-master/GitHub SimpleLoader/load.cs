﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using WindowsFormsApp2;

//    ___        __  __ _       
//   | _ )_  _  |  \/  (_)______
//   | _ | || | | |\/| | (_-(_-<
//   |___/\_, | |_|  |_|_/__/__/
//        |__/ 
// https://www.youtube.com/channel/UCOKeny3Q-RLaHT2PmFEpNTQ

namespace SimpleLoader
{
    public partial class load : MetroFramework.Forms.MetroForm
    {
        public load()
        {
            InitializeComponent();
        }
        private void checkonline()
        {
            
            try
            {
                using (var client = new WebClient())
                {
                    using (client.OpenRead("https://google.com/"))
                    {
                        
                        
                    }
                }
            }
            catch
            {
                
                
                
                timer1.Stop();
                MessageBox.Show("Conexão não existente"); // Coloque sua mensagem entre os paretenses casos o Usuario não tenha conexão com a internet
                Application.Exit();
                
            }
        }
        private void load_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            string atualização = @"C:\Loader";
            string checkcheat = @"C:\Loader\cheatupdate.txt";
            try
            { 
            metroProgressBar1.Increment(1);
            if (metroProgressBar1.Value == 5)
            {
                metroLabel1.Text = "Iniciando Loader";
            }
            if (metroProgressBar1.Value == 20)
            {
                metroLabel1.Text = "Testando conexão com a Internet";
                checkonline();
            }
            if (metroProgressBar1.Value == 60)
            {
                metroLabel1.Text = "Criando arquivos Locais";
                if (Directory.Exists(atualização) == true)
                {
                    try
                    {
                        string delete = @"C:\Loader\cheatupdate.txt"; 
                        File.Delete(delete);
                    }
                    catch
                    {
                        Application.Exit();
                    }
                    
                
                }
                Directory.CreateDirectory(atualização);
                WebClient wb = new WebClient();
                string mainpath = checkcheat ; 
                wb.DownloadFile("https://raw.githubusercontent.com/mija2611/Loader-Source-Code/main/cheatstatus.txt?token=ARMRAPULZKZIPYKJEAIWCJK7RC2D2", mainpath); // Coloque o link RAW do seu .txt que representa o status do cheat

            }
            if (metroProgressBar1.Value == 80)
            {
                metroLabel1.Text = "Loader Carregado com sucesso";
                
            }
            if (metroProgressBar1.Value == 100)
            {
                metroLabel1.Text = "Abrindo Loader";
                Form1 puxar = new Form1();
                timer1.Stop();
                puxar.Show();
                this.Hide();

            }
            }
            catch
            {
                timer1.Stop();
                MessageBox.Show("Erro desconhecido"); // Caso o loader não consiga iniciar
                Application.Exit();
            }


        }
    }
}
